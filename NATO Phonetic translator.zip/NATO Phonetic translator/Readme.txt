NATO Phonetic Translator:

    there are 2 files total:
        1. Translatopr.py Which is the main document that the program will be ran in
        2. Readme.txt Whis is this file
        
    
    The key words that the program output uses:
        Sentince:
            Displays the sentince that was Input
        Phonetic:
            Displays the letters that are being translated
        NATO:
            Displays the translated words
    
    Inputs:
        You can enter all ASCII letters and space
    
    Output:
        The program will output the requestid information in the order:
            
	    Sentence:  test

            Phonetic |   Nato
            ---------|-----
               T     | Tundra
               E     | Echo
               S     | Sierra
               T     | Tundra