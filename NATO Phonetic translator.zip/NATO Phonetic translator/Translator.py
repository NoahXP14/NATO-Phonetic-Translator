#NATO Phonetic Translator
print("Please enter your sentince!")
Word = (input (":> ")) #input
c = (Word.lower())

#interface
print()
print("Sentence: ", Word)
print()
print("Phonetic |   Nato")
print("---------|-----")

#reads the input and outputs The corresponding NATO Word Based on what letters are Input
def letter():
    for letter in c:
        if letter == "a":
            print("   A     | Alfa")
        elif letter == "b":
            print("   B     | Bravo")
        elif letter == "c":
            print("   C     | Charlie")
        elif letter == "d":
            print("   D     | Delta")
        elif letter == "e":
            print("   E     | Echo")
        elif letter == "f":
            print("   F     | Foxtrot")
        elif letter == "g":
            print("   G     | Golf")
        elif letter == "h":
            print("   H     | Hotel")
        elif letter == "i":
            print("   I     | India")
        elif letter == " j":
            print("   J     | Juliett")
        elif letter == "k":
            print("   k     | Kilo")
        elif letter == "l":
            print("   l     | Lima")
        elif letter == "m":
            print("   M     | Mike")
        elif letter == "n":
            print("   N     | November")
        elif letter == "o":
            print("   O     | Oscar")
        elif letter == "p":
            print("   P     | Papa")
        elif letter == "q":
            print("   Q     | Quebec")
        elif letter == "r":
            print("   R     | Romeo")
        elif letter == "s":
            print("   S     | Sierra")
        elif letter == "t":
            print("   T     | Tundra")
        elif letter == "u":
            print("   U     | Uniform")
        elif letter == "w":
            print("   V     | Victor")
        elif letter == "w":
            print("   W     |  Wiskey")
        elif letter == "x":
            print("   X     | X-Ray")
        elif letter == "y":
            print("   Y     | Yankee")
        elif letter == "z":
            print("   Z     | Zulu")
        elif letter == " ":
            print("      *Space*")
        
    print()


letter()
        